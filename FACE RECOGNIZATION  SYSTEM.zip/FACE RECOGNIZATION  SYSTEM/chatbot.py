from tkinter import*
from tkinter import ttk
from PIL import Image,ImageTk
 
class Chatbot:
    def __init__(self,root):
        self.root=root
        self.root.title("ChatBot")
        self.root.geometry("730x620+0+0")
        self.root.bind("<Return>",self.entry_func)

        main_frame=Frame(self.root,bd=4,bg="powder blue",width=610)
        main_frame.pack()

        img_chat=Image.open(r"images\chatbot.jpeg")
        img_chat=img_chat.resize((200,70))
        self.photoimg=ImageTk.PhotoImage(img_chat)
       
        Title_label=Label(main_frame,bd=3,relief=RIDGE,anchor='nw',width=730,compound=LEFT,image=self.photoimg,text='CHAT ME',font=("arial",30,"bold"),fg="green",bg="white")
        Title_label.pack(side=TOP)

        self.scroll_y=ttk.Scrollbar(main_frame,orient=VERTICAL)
        self.text=Text(main_frame,width=65,height=16,bd=3,relief=RIDGE,font=("arail",15),yscrollcommand=self.scroll_y.set)
        self.scroll_y.pack(side=RIGHT,fill=Y)
        self.text.pack()

        btn_frame=Frame(self.root,bd=4,bg="white",width=730)
        btn_frame.pack()

        label_1=Label(btn_frame,text="Type Something",font=("arial",14,"bold"),fg="green",bg="white")
        label_1.grid(row=0,column=0,padx=5,sticky=W)

        self.entry=StringVar()
        self.entry1=ttk.Entry(btn_frame,textvariable=self.entry,width=37,font=("arail",14,"bold"))
        self.entry1.grid(row=0,column=1,padx=5,sticky=W)

        self.send=Button(btn_frame,command=self.send,text="Send>>",font=("arail",15,"bold"),width=8,bg="green")
        self.send.grid(row=0,column=2,padx=5,sticky=W)

        self.clear=Button(btn_frame,command=self.clear,text="Clear Data",font=("times new roman",15,"bold"),width=8,bg="red",fg="black")
        self.clear.grid(row=1,column=0,padx=5,sticky=W)

        self.msg=''
        self.label_11=Label(btn_frame,text=self.msg,font=("arial",14,"bold"),fg="red",bg="white")
        self.label_11.grid(row=1,column=1,padx=5,sticky=W)

    # Function Declartion====================

    def entry_func(self,event):
        self.send.invoke()
        self.entry.set("")

    def clear(self):
        self.text.delete("1.0",END)
        self.entry.set("")

    def send(self):
        send='\t\t\t'+'You: '+self.entry.get()
        self.text.insert(END,'\n'+send)
        self.text.yview(END)

        if (self.entry.get()==''):
            self.msg="Please Enter some input"
            self.label_11.config(text=self.msg,fg="red")
        else:
            self.msg=''
            self.label_11.config(text=self.msg,fg="red")  

        if (self.entry.get()=='hello' or self.entry.get()=='hi' or self.entry.get()=='HELLO' or self.entry.get()=='HI' or self.entry.get()=='Hello' or self.entry.get()=='Hi'):
            self.text.insert(END,'\n\n'+'Bot: Hi'+'\n\n'+'1. How to keep software robust ?\n'+'2. How does Face recognition work ?\n'+'3. How does facial recognition work step by step ?\n'+'4. What are the benefits of using a face recognition system for attendance ?\n'+'5. What happens if someone tries to cheat the system?\n'+'6. How can administrators add or remove users from the system?\n'+'7. What kind of hardware is required to set up the face recognition attendance system ?\n'+'8. Bye')

        elif (self.entry.get()=='1'):
            self.text.insert(END,'\n\n'+'Data Quality: Ensure high-quality data for training the face recognition model. Use diverse datasets that cover a wide range of demographics, lighting conditions, and facial expressions. \n\nModel Selection: Choose a face recognition model that is well-suited for the task and has been tested for accuracy and reliability.\n\n Regular Updates: Keep the software up-to-date with the latest advancements and updates in face recognition technology to improve accuracy and security.\n\nSecurity Measures: Implement strong security measures to protect the system from unauthorized access and data breaches.\n\nTesting and Validation: Regularly test and validate the software to ensure it is working correctly and accurately identifying faces.\n\nUser Feedback: Gather feedback from users to identify any issues or areas for improvement in the software.\n\nError Handling: Implement robust error handling mechanisms to gracefully handle any errors or issues that may arise during operation\n.\nPerformance Optimization: Optimize the software for performance to ensure fast and reliable face recognition.\n\nDocumentation: Maintain thorough documentation of the software design, implementation, and operation to facilitate troubleshooting and future development.\n\nCompliance: Ensure that the software complies with relevant regulations and standards for privacy and data protection.')

        elif (self.entry.get()=='2'):
            self.text.insert(END,"\n\n"+"Facial recognition uses technology and biometrics — typically through AI — to identify human faces. It maps facial features from a photograph or video and then compares the information with a database of known faces to find a match. Facial recognition can help verify a person's identity but also raises privacy issues")

        elif (self.entry.get()=='3'):
            self.text.insert(END,"\n\nStep1. Enter the student details\nStep2. Face Detection\nStep3. The camera Detects and locates the image\nStep4. Train data\nStep5. Detect the faces\nStep5. update the attendence will reflect on the Software.")

        elif(self.entry.get()=='4'):
            self.text.insert(END,"\n\nAccuracy:     Face recognition systems can accurately identify individuals, reducing errors associated with manual attendance tracking or other biometric systems.\n\nEfficiency:     The automated nature of face recognition systems saves time compared to manual methods, especially in large organizations or classrooms.\n\nConvenience:    Employees or students can quickly and easily clock in or out without the need for cards, keys, or other physical identifiers.\n\nSecurity:  Face recognition systems can enhance security by ensuring that only authorized individuals are able to access certain areas or records.\n\nCost-effective:  While there may be an initial investment in setting up a face recognition system, it can be cost-effective in the long run due to reduced administrative overhead.\n\nDeterrent to fraud:       Face recognition systems are difficult to spoof, reducing the likelihood of fraudulent attendance practices.\n\nIntegration:    These systems can be integrated with existing attendance management software, making it easier to track attendance records and generate reports.\n\nCompliance:     Using face recognition for attendance can help organizations comply with regulations related to attendance tracking and data protection.")

        elif(self.entry.get()=='5'):
            self.text.insert(END,"\n\nUsing a Proxy:    Someone might try to have someone else clock in for them. This could involve asking a colleague or paying someone to impersonate them. Consequences could include disciplinary action if caught, ranging from warnings to termination, depending on company policies.\n\nWearing a Mask or Disguise:    If someone wears a mask or alters their appearance significantly, they might be able to evade the face recognition system. However, this is risky and could lead to suspicion and investigation if discovered.\n\nSpoofing the System:  Sophisticated cheaters might attempt to spoof the face recognition system using printed photos, masks, or other techniques. Modern systems often have safeguards against such attacks, but determined individuals might still find ways to exploit vulnerabilities.\n\nManipulating Images or Data:     Cheaters might try to manipulate the images stored in the system or tamper with the data to falsely record attendance. This could involve hacking into the system or accessing it through unauthorized means, which could have legal consequences.\n\nSocial Engineering:   Someone might try to manipulate or deceive the system administrators or IT personnel to gain unauthorized access or tamper with the system. This could involve tactics such as phishing, impersonation, or bribery.")

        elif(self.entry.get()=='6'):
            self.text.insert(END,"\n\nAccess the Administration Interface:  Administrators typically have access to a dedicated interface or dashboard where they can manage system settings, including user management.\n\nAdd Users:Navigate to the user management section of the interface.\nSelect the option to add a new user.\nEnter the necessary information for the new user, which may include their name, employee ID, and a reference photo for face recognition.\nSave the user's information, and the system should now recognize them for attendance tracking.\n\nRemove Users:\nLocate the user management section of the interface.\nFind the user you want to remove from the system.\nSelect the option to delete or remove the user.\nConfirm the action, and the user's data should be removed from the system.\n\nEdit User Information:    Administrators may also have the ability to edit existing user information, such as updating contact details or changing the reference photo for face recognition.\n\nReview Access Logs:     After making changes to user accounts, administrators may want to review access logs or audit trails to ensure that changes were made correctly and to monitor system activity for any suspicious behavior.\n\nTraining and Support:    It's essential for administrators to receive proper training on how to manage user accounts within the face recognition attendance system. Additionally, having access to technical support or documentation can help troubleshoot any issues that may arise during user management tasks.")
       
        elif(self.entry.get()=='7'):
            self.text.insert(END,"\n\nCamera:   A high-resolution camera capable of capturing clear images of faces is essential. It's preferable to use a camera with features like autofocus, low-light sensitivity, and high frame rates to ensure accurate face detection and recognition.\n\nProcessor:    The system needs a robust processor to handle the computational tasks associated with facial recognition algorithms efficiently. This could be a dedicated processing unit or a powerful CPU/GPU combination, depending on the scale and requirements of the system.\n\nMemory:     Sufficient RAM is necessary for storing and processing facial recognition data in real-time. The amount of memory required depends on factors such as the number of users, the frequency of attendance checks, and the complexity of the recognition algorithms.\n\nStorage:    The system needs storage space to store user profiles, facial templates, attendance records, and other relevant data. This could be in the form of SSDs or HDDs, depending on the storage requirements and performance needs of the system.\n\nNetworking Equipment:    The system may require networking equipment such as routers, switches, and Ethernet cables to connect the hardware components and enable communication with other devices or servers.\n\nDisplay:   A display screen may be necessary for users to interact with the system, especially in self-service kiosk setups where individuals need to verify their attendance or administrators need to manage user accounts.\n\nPower Supply:     Reliable power sources are essential to ensure uninterrupted operation of the system. This includes backup power options like uninterruptible power supplies (UPS) to prevent data loss or system downtime during power outages.\n\nEnclosures and Mounts:  Depending on the deployment environment, the hardware components may need to be housed in enclosures or mounted securely to walls, ceilings, or stands to protect them from damage and vandalism.\n\nOptional Components:   Depending on specific requirements, additional hardware components such as thermal sensors for temperature screening, proximity sensors for access control, or biometric scanners for multi-factor authentication may be integrated into the system.\n\nIntegration with Existing Systems:  In some cases, the face recognition attendance system may need to integrate with existing hardware or software systems such as access control systems, HR databases, or time and attendance management software.")

        elif(self.entry.get()=='8'):
            self.text.insert(END,"\n\nBot: Thank you for chatting!!!\n\t\t\tHave a nice day.")

        else:
            self.text.insert(END,"\n\n"+"Bot: Sorry I didn't get it")
       
if __name__=='__main__':
    root=Tk()
    obj=Chatbot(root)
    root.mainloop()
