import mysql.connector as sql
conn=sql.connect(host="localhost",user="root",password="Avish@613")

if conn.is_connected()==False:
    print("Not Connected")
conn.close()